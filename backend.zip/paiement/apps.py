from django.apps import AppConfig


class PaiementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'paiement'
